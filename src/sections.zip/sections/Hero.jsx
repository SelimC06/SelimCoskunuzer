import HeroText from "../components/HeroText";
import ParallaxBackground from "../components/ParallaxBackground";
import {Canvas} from "@react-three/fiber";
import { Car } from "../components/Car";
import { OrbitControls, Environment } from "@react-three/drei";
import { useMediaQuery } from "react-responsive";
import Loader from "../components/Loader";
import { Suspense } from "react";

const Hero = () => {
    const isMobile =useMediaQuery({maxWidth: 853});
    return (
        <section className="flex items-start justify-center md:items-start md:justify-start min-h-screen overflow-hidden c-space">
            <HeroText />
            <ParallaxBackground />
            <figure className="absolute inset-0" style={{width: "100vw", height: "100vh"}}>
                    <Canvas camera={{position:[0,1,3]}} gl={{ toneMappingExposure: 0.85 }}>
                        <Suspense fallback={<Loader />}>
                        <ambientLight intensity={0.2} />
                        <directionalLight
                            position={[-4, 6, 3]}
                            intensity={0.6}
                        />
                        <directionalLight
                            position={[4, 2, -5]}
                            intensity={0.4}
                        />
                        <Environment preset="warehouse" intensity={0.45} /> {/* Studio also works */}
                        <Car scale={isMobile ? 0.4 : 1.1} enableZoom={false} />
                        </Suspense>
                    </Canvas>
            </figure>
        </section>
    )
}

export default Hero;
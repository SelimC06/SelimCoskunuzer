import React from "react";

const About = () => {
    return (
        <section className="c-space section-spacing">
            <h2 className="text-heading">About Me</h2>
        </section>
    )
}

export default About;
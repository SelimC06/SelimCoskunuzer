import {motion} from "motion/react";

const HeroText = () => {
    const variants ={
        hidden:{opacity:0, x:-50},
        visible: {opacity:1, x:0},
    }
    return <div className="z-10
    mt-20 text-center md:mt-40 md:text-left rounded-3xl bg-clip-text">
        <div className="flex-col hidden md:flex c-space">
            <motion.h1 className="text-5xl font-medium text-[rgba(71,68,72,1)]"
            variants={variants}
            initial="hidden"
            animate="visible"
            transition={{delay:.8}}>Selim Coskunuzer</motion.h1>
            <div className="flex flex-col items-start">
                <motion.p className="text-6xl font-medium text-[rgba(71,68,72,1)]"
                variants={variants}
                initial="hidden"
                animate="visible"
                transition={{delay:1}}>Machine Learning Engineer</motion.p>
                <div></div>
                <motion.p className="text-5xl font-medium text-[rgba(71,68,72,1)]"
                variants={variants}
                initial="hidden"
                animate="visible"
                transition={{delay:1.2}}>Texas A&M University</motion.p>
            </div>
        </div>
        <div className="flex flex-col space-y-6 md:hidden">
            <motion.p className="text-4xl font-medium text-black"
            variants={variants}
            initial="hidden"
            animate="visible"
            transition={{delay:.8}}>Selim Coskunuzer</motion.p>
            <div>
                <motion.p className="text-4xl font-black text-black"
                variants={variants}
                initial="hidden"
                animate="visible"
                transition={{delay:1}}>
                    Machine Learning Engineer
                </motion.p>
                <motion.p className="text-3xl font-black text-black"
                variants={variants}
                initial="hidden"
                animate="visible"
                transition={{delay:1.2}}>
                    Texas A&M University
                </motion.p>
            </div>
        </div>
    </div>
};

export default HeroText;